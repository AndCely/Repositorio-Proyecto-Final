# Proyecto_Final_Log_Mat
Proyecto final de Lógica Matemática y Programación.

Autor: Santiago Andres Cely Rincon

mas lineas
